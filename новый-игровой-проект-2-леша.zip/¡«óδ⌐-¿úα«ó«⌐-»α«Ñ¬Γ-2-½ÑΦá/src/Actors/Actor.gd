extends CharacterBody2D
class_name Actor

# Called when the node enters the scene tree for the first time.
func _physics_process(delta: float) -> void:
	velocity.x = 300
	move_and_slide()
