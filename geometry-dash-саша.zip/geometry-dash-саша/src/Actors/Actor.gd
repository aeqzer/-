extends CharacterBody2D
class_name Actor

func _physics_process(delta: float) -> void:
	velocity.x = 300
	move_and_slide()
