extends Actor

var jump_time = 0
var jump_max_time = 15


func _physics_process(delta: float) -> void:
	var direction_x = get_direction_x()
	var direction_y = get_direction_y()
	velocity.x = speed * direction_x
	velocity.y = gravity * direction_y
	move_and_slide()

func get_direction_x() -> float:
	return Input.get_action_strength("move right") - Input.get_action_raw_strength("move left")
func get_direction_y() -> float:
	var direction_y = 0
	if Input.is_action_just_pressed("jump") and is_on_floor() \
	or jump_time > 0 and jump_time < jump_max_time and !is_on_ceiling():
		direction_y = -1
		jump_time += 1
	else:
		direction_y = 1
		jump_time = 0
	return direction_y


func _on_enemy_detector_area_entered(area: Area2D) -> void:
	jump_time = 1


func _on_enemy_detector_body_exited(body: Node2D) -> void:
	pass # Replace with function body.

func _on_EnemyDetector_body_entered(body):
	queue_free()
