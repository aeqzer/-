import check
import plant
import move
import till

till.tilling()
while True:
	check.checking()
	plant.planting()
	move.moving()