import check_pumpkins

def planting():
	size =  get_world_size() 
	half = size/2 - 1
	x = get_pos_x()
	y = get_pos_y()
	border = [0, size - 1]
	width = size / 4
	center = range(width , size - width )
	if y in border:
		plant(Entities.Sunflower)
	elif x in center and y in center:
		plant(Entities.Pumpkin)
		if x == y and y == size - width - 1:
			check_pump
	elif y == 1:
		plant(Entities.Tree)
	elif y == get_world_size - 2
		plant(Entities.Grass)
	elif x < 2:
		plant(Entities.Carrot)
	else:
		plant(Entities.Cactus)
		
		
		