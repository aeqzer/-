 def checking():
	if get_water()<0.5:
		use_item(Items.Water)
	if can_harvest():
		harvest()
	if get_ground_type()==Grounds.Grassland:
		till()