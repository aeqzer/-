@tool
extends Area2D

@onready var anim_player: AnimationPlayer = get_node("AnimationPlayer")

@export var next_scene: PackedScene

func _get_configuration_warnings() -> PackedStringArray:
	return "Параметр следующей сцены не может быть пустым" if not next_scene else []
	
func teleport() -> void:
	anim_player.play("fade_in")
	await(anim_player)
	get_tree().change_scene_to_packed(next_scene)


func _on_body_entered(body: Node2D) -> void:
	teleport()
