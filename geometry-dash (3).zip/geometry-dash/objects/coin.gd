extends Area2D

@onready var animation: AnimationPlayer = get_node("AnimationPlayer")

func _on_body_entered(body: Node2D) -> void:
	animation.play("fade_out")
