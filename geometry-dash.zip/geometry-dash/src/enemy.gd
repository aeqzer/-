extends "res://src/Actors/Actor.gd"

var was_on_wall = false

func _ready() -> void:
	velocity.x = speed 
 
func _physics_process(delta: float) -> void:
	velocity.y += gravity * delta 
	if is_on_wall() and not was_on_wall:
		velocity.x += -1.0
	was_on_wall = is_on_wall()
	move_and_slide()


func _on_stomp_detector_body_entered(body: Node2D) -> void:
	if body.global_position.y > get_node("StompDetector").global_position.y:
		return 
	die()
	
func die() -> void:
	queue_free()
