extends CharacterBody2D
class_name Actor

@export var gravity = 700
@export var speed =  300
