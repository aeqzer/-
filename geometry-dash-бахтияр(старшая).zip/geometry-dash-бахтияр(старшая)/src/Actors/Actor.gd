extends CharacterBody2D
class_name Actor

@export var gravity = 300
@export var speed = 300

func _physics_process(delta: float) -> void:
	velocity.y = gravity
	velocity.x = speed
	move_and_slide ()
