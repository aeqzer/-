while True:
	for i in range (3):
		if can_harvest():
			harvest()
		till()
		plant(Entities.Carrot)
	move(North)
	