def plant_and_harverst():
	size = get_world_size()
	pumpkin_x0,pumpkin_x1 = 0, size / 2
	pumpkin_y0,pumpkin_y1, = 0, size / 2 
	cactus_x0,cactus_x1 = size / 2 , size
	cactus_y0,cactus_y1 = 0, size / 2
	tree_x0, tree_x1, = 0 ,size // 3
	tree_y0,tree_y1, = size / 2 , size - 1
	grass_x0,grass_x1 = size //3 ,size //3 * 2
	grass_y0,grass_y1 = size / 2, size - 1
	carrot_x0,carrot_x1 = size //3 * 2, size
	carrot_y0,carrot_y1 = size / 2,size - 1
	sun_x0,sun_x1 = 0,size
	sun_y0,sun_y1 = 0,size - 1,size 
	plant_and_harvest_to(pumpkin_x0,pumpkin_x1,pumpkin_y0,pumpkin_y1, Entities.Pumpkin)
	check_pumpkins.check_pumpkins(pumpkin_x0,pumpkin_x1,pumpkin_y0,pumpkin_y1)
	plant_and_harvest_to(cactus_x0,cactus_x1,cactus_y0,cactus_y1,Entities.Cactus)
	plant_and_harvest_to(tree_x0, tree_x1,tree_y0,tree_y1,Entities.Tree)
	plant_and_harvest_to(grass_x0,grass_x1,grass_y0,grass_y1,Entities.Grass)
	plant_and_harvest_to(carrot_x0,carrot_x1,carrot_y0,carrot_y1,Entities.Carrot)
	plant_and_harvest_to(sun_x0,sun_x1,sun_y0,sun_y1,Entities.Sunflower)