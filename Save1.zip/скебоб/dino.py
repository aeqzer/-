def dino():
	size = get_world_size()
	change_hat(Hats.Dinosaur_Hat)
	while can_move(East) or can_move(North) or can_move(South):
		for i in range(size):
			move(East)
		move(North)
		for i in range(size/2):
			for i in range(size - 2):
				move(North)
			move(West)
			for i in range(size - 2):
				move(South)
			move(West)
		move(South)
	change_hat(Hats.Gray_hat)