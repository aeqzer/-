def move_to(x, y):
	while get_pos_x() != x:
		if x > get_pos_x():
			move(East)
		if x < get_pos_x():
			move(West)
	while get_pos_y() != y:
		if y > get_pos_y():
			move(North)
		if y < get_pos_y():
			move(South)