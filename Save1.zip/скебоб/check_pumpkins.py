import move

def check_pumpkins(x0,x1,y0,y1):
	for x in range(x0,x1):
		for y in range(y0,y1):
			move.move_to(x,y) 
			while get_entity_type() !=Entities.Pumpkin:
				plant(Entities.Pumpkin)		
	
	