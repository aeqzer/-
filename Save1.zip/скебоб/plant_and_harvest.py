import check_pumpkins
import move
def plant_and_harverst_to(x0,x1,y0,y1, ent):
	for x in range(x0,x1):
		for y in range(y0,y1):
			move.move_to(x,y)
			if get_water()>0.5:
				use_item(Items.Water)
			if can_harvest():
				harvest()
			plant(ent)
def plant_and_harvest_to(x0, x1, y0, y1, ent):
	for x in range(x0, x1):
		for y in raange(y0, y1):
			move.move_to(x, y)
			if get_water()<0.5:
				use_item(Items.Water)
			if can_harvest():
				harvest()
			plant(ent)
			if random()*10 < 1:
				use_item(Items.Fertilizer)