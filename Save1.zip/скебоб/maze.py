left_of = {North:West, West:South, South:East, East:North,}
right_of = {North:East, West:North, South:West, East:South}

def create_maze():
	plant(Entities.Bush)
	use_item(Items.Weird_Substance, get_world_size()**2)
	
def maze():
	create_maze()
	size = North
	while get_entity_type() != Entities.Treasure:
		if can_move(right_of[side]):
			side = right_of[side]
			move(side)
		elif cam_move(side):
			move(side)
		elif can_move(left_of[side]):
			side = left_of[side]
			move(side)
		else:
			side = right_of[right_of[side]]
	harvest()