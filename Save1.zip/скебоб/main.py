import plant_and_harvest
import till
import dino
import move

def clear():
	size = get_world_size()
	for x in range(size):
		for y in range(size):
			move.move_to(x, y)
			harvest()
			
change_hat(Hats.Gray_Hat)
clear()
move.move_to(0, 0)
dino.dino()
till.tilling()
while True:
	plant_and_harvest.plant_and_harvest()